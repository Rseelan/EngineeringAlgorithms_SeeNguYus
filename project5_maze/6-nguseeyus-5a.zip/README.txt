Hey! 
Don't forget to change the names of things like the input file!

Important!!! the recursive function takes in destination and start parameters just like in the maze::print function!
So if you want to test different size mazes, you have to change the recursive function's parameters!!!!